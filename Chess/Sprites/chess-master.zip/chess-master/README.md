Chess
--------------
<img src="http://i287.photobucket.com/albums/ll128/patmaster/unnamed_zps68986906.png" width="150" alt="Knight" align="right">

### Compiling
`make compile`

*You must use Java 1.7+!!*

Of course you should be using the latest version anyway..

### Features
  - Network play

### How to play on a network
  1. Start the client on both computers
  2. On one, Connect -> Set up a connection client
  3. Enter any port that's available (like, 6789)
  4. On the other computer, Connect -> Connect to IP/Port
  5. Enter the IP of the first computer and the port you just chose
  6. Play

### To Do
  - Chat only works if the player making the move is sending a message.
  - When running the server and waiting for connection, the application freezes until someone connects
  - Bots

### Credits
  - My childhood chess mentors Ted and Paul
  - Mom for setting up her library's chess program and bringing home a chess set
  - Mr. Boyt and my middle school chess team friends
  - Wikipedia for piece images
